<p align="center">
  <img src="https://telegra.ph/file/2bf73ca1e5d55cc186ba3.jpg">
</p>

<h4><p align="center"> REYZU ROBOT </p></h4>

<p align="center">Reyzu Robot is a modular bot running on python3 with anime theme and have a lot features.</p>

<p align="center">
<a href="https://t.me/ReyzuRobot"> <img src="https://img.shields.io/badge/Reyzu-Robot-blue?&logo=telegram" alt="Reyzu on Telegram" /> </a><br>
<a href="https://python-telegram-bot.org"> <img src="https://img.shields.io/badge/PTB-13.10-white?&style=flat-round&logo=github" alt="Python Telegram Bot" /> </a>
<a href="https://github.com/psf/black"><img alt="Code style: black" src="https://img.shields.io/badge/code%20style-black-000000.svg"></a><br>
<a href="https://docs.telethon.dev"> <img src="https://img.shields.io/badge/Telethon-1.24.0-red?&style=flat-round&logo=github" alt="Telethon" /> </a>
<a href="https://docs.python.org"> <img src="https://img.shields.io/badge/Python-3.10.1-purple?&style=flat-round&logo=python" alt="Python" /> </a><br>
<a href="https://GitHub.com/kennedy-ex/EmikoRobot"> <img src="https://img.shields.io/badge/Maintained-Yash-yellow.svg" alt="Maintenance" /> </a><br>
<a href="https://github.com/kennedy-ex/EmikoRobot/blob/main/LICENSE"> <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License" /> </a>
<a href="https://makeapullrequest.com"> <img src="https://img.shields.io/badge/PRs-Welcome-blue.svg?style=flat-round" alt="PRs" /> </a>
</p>

### TUTORIAL

- First fork this repository.
- Then change the deploy link bellow.
- This step must be doing because mine link is violates the salesforce acceptable use.
- You can just change the name of github on deploy link and done, the repos able to deploy on heroku.
- Full Tutorial - [![Full Tutorial](https://img.shields.io/badge/Watch%20Now-blue)](https://youtu.be/GMaYMYhf_Vk)

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/melatirisni/EmikoRobot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

```
This Bot is Created by KennedyProject, If your kanging this without fork at least give a credit to get a smile of my hard work. 
- EmikoRobot
- YoneRobot
- SaitamaRobot 
- TheRealPhoenixBot
- DaisyX 
- WilliamButcherBot
```

### Support
<p>
<a href="https://t.me/ReyzuRobot"> <img src="https://img.shields.io/badge/Reyzu-Ex-blue?&logo=telegram" alt="Reyzu on Telegram" /> </a><br>
<a href="https://t.me/komunitas_virtual"> <img src="https://img.shields.io/badge/Support-Chat-blue?&logo=telegram" alt="Support Chat" /> </a><br>
<a href="https://t.me/komunitasvirtual"> <img src="https://img.shields.io/badge/Update-Channel-blue?&logo=telegram" alt="Update Channel" /> </a><br>
</p>

## Credit 

• [Reyzu](https://github.com/Reyzuuu)

• [Sena](https://github.com/kennedy-ex)

• [Arya](https://github.com/Aryazakaria01)

• [Kyy](https://github.com/zxcskyy)
